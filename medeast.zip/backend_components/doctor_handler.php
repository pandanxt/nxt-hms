<?php
    // Start Session 
    session_start();
    // Query Params
    $q = (isset($_GET['q']) ? $_GET['q'] : '');
    $id = (isset($_GET['id']) ? $_GET['id'] : '');
    $val = (isset($_GET['val']) ? $_GET['val'] : '');
    // Connection File
    include "connection.php";
    
    // Add Medeast Doctor Query
    if($q == 'ADD_DOCTOR') {
        $uid = mysqli_real_escape_string($db, $_POST['uuId']);
        $name = mysqli_real_escape_string($db, $_POST['name']);
        $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
        $department = mysqli_real_escape_string($db, $_POST['department']);
        $by = mysqli_real_escape_string($db, $_POST['staffId']);

        $sql = "SELECT * FROM `me_doctor` WHERE `DOCTOR_NAME` = ? OR `DOCTOR_MOBILE` = ?";
        $stmt = mysqli_stmt_init($db);
            
        if (!mysqli_stmt_prepare($stmt,$sql)) {
            echo "Error: " . $sql . "" . mysqli_error($stmt);
        }else{
            mysqli_stmt_bind_param($stmt,"ss",$name,$mobile);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $resultCheck = mysqli_stmt_num_rows($stmt);
                
                if ($resultCheck > 0) {
                    echo "name or mobile number already taken!";
                }else{
                        $sql = "INSERT INTO `me_doctor`(`DOCTOR_UUID`,`DOCTOR_NAME`, `DOCTOR_MOBILE`, `DEPARTMENT_UUID`, `STAFF_ID`) VALUES (?,?,?,?,?)";
                        mysqli_stmt_execute($stmt);
                    
                        if (!mysqli_stmt_prepare($stmt,$sql)) {
                            echo "Error: " . $sql . "" . mysqli_error($stmt);
                        }else{
                            mysqli_stmt_bind_param($stmt,"sssss",$uid,$name,$mobile,$department,$by);
                            mysqli_stmt_execute($stmt);
                            echo "Form Has been submitted successfully";
                        }			
                    }
            }
        mysqli_stmt_close($stmt);
        mysqli_close($db);
    }

    // Medeast Doctor Status Update 
    if ($q == 'STATUS_DOCTOR') {
        if(mysqli_query($db, "UPDATE `me_doctor` SET `DOCTOR_STATUS`= '$val' WHERE `DOCTOR_UUID` = '$id'")) {
            echo 'Status Updated successfully';
        } else {
            echo "Error: " . $sql . "" . mysqli_error($db);
        }
    }

    // Update Medeast Dept Query
    if ($q == 'EDIT_DOCTOR') {
        $uuid = mysqli_real_escape_string($db, $_POST['uuid']);
        $name = mysqli_real_escape_string($db, $_POST['docName']);
        $mobile = mysqli_real_escape_string($db, $_POST['docMobile']);
        $department = mysqli_real_escape_string($db, $_POST['docDepartment']);
        
        if(mysqli_query($db, "UPDATE `me_doctor` SET `DOCTOR_NAME`='$name',`DOCTOR_MOBILE`='$mobile',`DEPARTMENT_UUID`='$department' WHERE `DOCTOR_UUID` = '$uuid'"))
        {
            echo 'Doctor Updated Successfully';
        } else {
            echo "Error: " . $sql . "" . mysqli_error($db);
        }	
    }

    // Medeast Delete Query
    if($q == 'DELETE_DOCTOR') {
        if(mysqli_query($db, "DELETE FROM `me_doctor` WHERE `DOCTOR_UUID` ='$id'")) {
            // echo 'User Deleted Successfully';
            echo '<script>window.location = "../doctors.php?action=deleted";</script>';
        } else {
            echo "Error: " . $sql . "" . mysqli_error($db);
        }
    }

    // Get Medeast Room by Id
    if ($q == 'GET-DOCTOR-BY-ID') { 

        $user = "SELECT *,`DEPARTMENT_NAME` FROM `me_doctor` INNER JOIN `me_department` WHERE  `me_doctor`.`DEPARTMENT_UUID` = `me_department`.`DEPARTMENT_UUID` AND `DOCTOR_UUID` = '$id'";
        $result = mysqli_query($db, $user) or die (mysqli_error($db));
        $resultCheck = mysqli_num_rows($result);
        if ($resultCheck != 0) {
            while ($row = mysqli_fetch_array($result)) {
                echo "<div class='row'>
                <div class='col-md-6'>
                <div class='col-md-12 clearfix'>
                <div class='row'><label>Uuid:</label> &nbsp;<p> $row[DOCTOR_UUID]</p></div>
                <div class='row'><label>Mobile:</label>&nbsp;<p> $row[DOCTOR_MOBILE]</p></div>";
                if ($_SESSION['role'] == "admin") {  
                    echo "<div class='row'>
                    <label>Options: </label>
                    &nbsp;
                    <label class='switch' style='margin-top: 3px;'>";
                        if ($row['DOCTOR_STATUS'] == 0) {
                            echo "<input type='checkbox' onchange='handleStatus(this);' data-uuid='".$row['DOCTOR_UUID']."' value='".$row['DOCTOR_STATUS']."'>";                          
                        }elseif ($row['DOCTOR_STATUS'] == 1) {
                            echo "<input type='checkbox' checked='true' onchange='handleStatus(this);' data-uuid='".$row['DOCTOR_UUID']."' value='".$row['DOCTOR_STATUS']."'>";
                        }
                    echo "<span class='slider round'></span>
                    </label>
                    &nbsp;
                    <a href='javascript:void(0);' onclick='editDoctor(this);' data-uuid='$row[DOCTOR_UUID]' data-toggle='modal' data-target='#edit-doctor'>
                        <i class='fas fa-edit'></i>
                    </a>
                    &nbsp;
                    <a onClick=\"javascript: return confirm('Please confirm deletion');\" href='backend_components/doctor_handler.php?q=DELETE_DOCTOR&id=$row[DOCTOR_UUID]' style='color:red;'><i class='fas fa-trash'></i></a>
                    </div>";
                }
                echo "</div>
                </div>
                <div class='col-md-6'>
                <div class='col-md-12 clearfix'>
                    <div class='row'><label>Name:</label>&nbsp;<p> $row[DOCTOR_NAME]</p></div>
                    <div class='row'><label>Dept:</label> &nbsp;<p> $row[DEPARTMENT_NAME]</p></div>
                    <div class='row'><label>Date:</label> &nbsp;<p> $row[DOCTOR_DATE_TIME]</p></div>
                    </div>
                </div>
            </div>";
            }
        }
    }

    // Edit Medeast User by Id
    if ($q == 'EDIT-DOCTOR-BY-ID') { 
    
        $user = "SELECT *, `DEPARTMENT_NAME` FROM `me_doctor` INNER JOIN `me_department` WHERE `me_doctor`.`DEPARTMENT_UUID` = `me_department`.`DEPARTMENT_UUID` AND `DOCTOR_UUID` = '$id'";
        $result = mysqli_query($db, $user) or die (mysqli_error($db));
            $resultCheck = mysqli_num_rows($result);
            if ($resultCheck != 0) {
                while ($row = mysqli_fetch_array($result)) {
                    echo "
                    <input type='text' name='uuid' id='uuid' value='$row[DOCTOR_UUID]' hidden readonly>
                    <div class='row'>
                    <div class='col-md-6'>
                    <div class='form-group'>
                        <label>Name</label>
                        <input type='text' class='form-control' name='docName' id='docName' placeholder='Enter Doctor Name ...' value='$row[DOCTOR_NAME]' required>
                    </div>
                    <div class='form-group'>
                        <label>Mobile</label>
                        <input type='text' class='form-control' name='docMobile' id='docMobile' placeholder='Enter Doctor Mobile ...' value='$row[DOCTOR_MOBILE]' required>
                    </div>
                    </div>
                    <div class='col-md-6'>
                    <div class='form-group'>
                    <label>Department</label>
                    <select class='form-control select2bs4' name='docDepartment' id='docDepartment' style='width: 100%;'>
                    <option selected value='$row[DEPARTMENT_UUID]'>$row[DEPARTMENT_NAME]</option>";

                        $dept = 'SELECT `DEPARTMENT_UUID`,`DEPARTMENT_NAME` FROM `me_department` WHERE `DEPARTMENT_STATUS` = 1';
                        $result = mysqli_query($db, $dept) or die (mysqli_error($db));
                          while ($row = mysqli_fetch_array($result)) {
                            $id = $row['DEPARTMENT_UUID'];  
                            $name = $row['DEPARTMENT_NAME'];
                            echo '<option value="'.$id.'">'.$name.'</option>'; 
                        }

                    echo "</select>
                  </div>
                    </div>
                </div>";
                }
            }
    }   
?>