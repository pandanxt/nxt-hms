<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Powered By: <a href="http://pandanxt.com">Panda Nxt</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020-2022 <a href="https://medeast.net">MedEast | Healthcare</a>.</strong> All rights reserved.
  </footer>